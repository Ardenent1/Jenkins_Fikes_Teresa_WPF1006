/*
 Teresa Jenkins Fikes
 WPF 1408 Section 01
 Go To training Week 2
 */

//array-Halloween Candy

prompt = (How much Halloween Candy)
var choices = [2,3,4,5,6,7]
var total = HerseyCandy[0] + nestleCandy [1] + marsCandy[2] +  taffyCandy{3} + homemadeCandy{4} + toffeeCandy[5];

console.log(total);
