/*
 Teresa Jenkins Fikes
 WPF 1408 Section 01
 Go To training Week 2
 */

//alert("How much money does Mary need for gas to visit me?");
//Create a js file that will tell us how much money Mary needs for her trip



alert("Welcome "+Mary+"!  Let's go ahead and figure out the cost of gas to get here." );

//Ask the user what is the mpg of her car?

var mpg = prompt("What is the mpg of your car?");

//console.log out the response
console.log(mpg);

//Mary's car gets 34 miles to the gallon

var mpg = 34;
//console.log out the response
console.log(34);

//ask the user the local gas price per gallon
alert(What is the local gas price per gallon?);

var gasPricePerGallon = prompt("What is the local gas price per gallon?");
//console.log out the response

var gasPricePerGallon = $3.25;
console.log(gasPricePerGallon);

//trip mileage one way from Corinth, MS to Webb, AL is 375 miles


var miles = 375;
console.log(miles);
alert(var answer);


var answer = 375 / 34 * $3.25;
console.log(answer);

