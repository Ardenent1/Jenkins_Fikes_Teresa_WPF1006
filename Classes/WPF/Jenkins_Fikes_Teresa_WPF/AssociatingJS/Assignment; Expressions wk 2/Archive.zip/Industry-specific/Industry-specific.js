/*
 Teresa Jenkins Fikes
 WPF 1408 Section 01
 Go To training Week 2
 */

//Prompt and Alert
Var result = prompt("Graphic Artist use Geometry in web design, so let us see what the area of a triangle is");


//Triangle formula

var base=prompt("We are calculating the area of a triangle. \nPlease enter the base");
var verticalHeight = prompt("Please enter the height.");
var area = 1/2 * b * h; //calculates with that info
//console.log(area); //prints it out to console

var resultTwo =("The area of your rectangle is " + area + " sq feet");

alert(resultTwo);